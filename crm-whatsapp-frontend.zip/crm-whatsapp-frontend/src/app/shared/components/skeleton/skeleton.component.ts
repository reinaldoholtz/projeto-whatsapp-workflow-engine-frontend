import { Component, input } from '@angular/core';

@Component({
  selector: 'app-skeleton',
  standalone: true,
  template: `
    <div class="space-y-3">
      @for (item of rows(); track $index) {
        <div class="skeleton h-10 rounded-lg w-full"></div>
      }
    </div>
  `
})
export class SkeletonComponent {
  rows = input(5, { transform: (v: number) => Array(v).fill(0) });
}
